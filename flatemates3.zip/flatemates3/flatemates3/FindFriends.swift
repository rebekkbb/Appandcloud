//
//  FindFriends.swift
//  flatemates3
//
//  Created by Rebekka Brøyn on 01/01/2019.
//  Copyright © 2019 Rebekka Brøyn. All rights reserved.
//

import UIKit
import FBSDKLoginKit
import SwiftyJSON

class FindFriends: UITableViewController {
    var friendsList = [Friend]()
    var sampleData:[Dictionary<String, Any>] = [
        [
            "name" : "Jon Snow",
            "house": "Stark, Targaryen",
            "picture": #imageLiteral(resourceName: "party")
        ],
        [
            "name" : "Daenerys Targaryen",
            "house" : "Targaryen",
            "picture": #imageLiteral(resourceName: "party")
        ],
        [
            "name" : "Tyrion Lannister",
            "house" : "Lannister",
            "picture": #imageLiteral(resourceName: "party")
        ],
        [
            "name" : "Arya",
            "house": "Stark",
            "picture": #imageLiteral(resourceName: "party")
        ]
    ]
    
    class Friend{
        let id: Int
        let name: String
        let image: String
        init(id: Int, name:String, image: String){
            self.id = id
            self.name = name
            self.image = image
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        let cellNib = UINib(nibName: "TableViewCell", bundle:nil)
        self.tableView.register(cellNib, forCellReuseIdentifier: "cell")
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return sampleData.count
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
        let character = sampleData[indexPath.row]
        cell.namelabel.text = character["name"] as? String
        cell.profilepic.image=character["picture"] as? UIImage
        /*let imgurl = URL(string: friendsList2[indexPath.row].image)
        let data = try? Data(contentsOf: imgurl!)
        cell.textLabel?.text = friendsList2[indexPath.row].name
        cell.namelb.text = friendsList2[indexPath.row].name
        cell.imgView.image = UIImage(data: data!)*/
        // Configure the cell...

        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath)->CGFloat{
        return 120.0
    }
    func getfriends(){
        let params = ["fields": "id, first_name, last_name, middle_name, name, email, picture.type(normal)"]
        FBSDKGraphRequest(graphPath: "me/friends", parameters: params).start(completionHandler: { (connection, result, error) -> Void in
            
            if error != nil {
                print(error)
                return
                /* Handle error */
            }
            
            let json=JSON(result)
            print(json)
            let users = json["data"]
            //print(users)
            //print(json)
            let k = json["summary"]["total_count"].intValue
            for i in 0..<k{
                let id = users[i]["id"].intValue
                let name = users[i]["name"].stringValue
                let picture = users[i]["picture"]["data"]["url"].stringValue
                let friend = Friend(id: id, name: name, image: picture)
                self.friendsList.append(friend)
            }
        })
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
