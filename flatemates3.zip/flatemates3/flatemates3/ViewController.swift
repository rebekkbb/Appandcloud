//
//  ViewController.swift
//  flatemates3
//
//  Created by Rebekka Brøyn on 27/10/2018.
//  Copyright © 2018 Rebekka Brøyn. All rights reserved.
//

import UIKit
import FBSDKLoginKit



class ViewController: UIViewController, FBSDKLoginButtonDelegate{
        func loginButton(_ loginButton: FBSDKLoginButton!, didCompleteWith result: FBSDKLoginManagerLoginResult!, error: Error!) {
        
        if error != nil{
            print(error)
            return
        }
        fetchProfile()
        print("loginsuccess")
        performSegue(withIdentifier: "logged_in", sender: self)
    }
    
    func loginButtonDidLogOut(_ loginButton: FBSDKLoginButton!) {
        print("didlogout")
    }
    
    @IBOutlet weak var startScrollView: UIScrollView!
    
    var  imageArray = [UIImage]()
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        imageArray=[#imageLiteral(resourceName: "party"),#imageLiteral(resourceName: "toilett"),#imageLiteral(resourceName: "prize"),#imageLiteral(resourceName: "vask")]
        for i in 0..<imageArray.count{
            let imageView=UIImageView()
            imageView.image=imageArray[i]
            imageView.contentMode = .scaleAspectFit
            let xPosition=self.startScrollView.frame.width*CGFloat(i)
            imageView.frame=CGRect(x: xPosition, y: 0, width: self.startScrollView.frame.width, height: self.startScrollView.frame.height)
            startScrollView.contentSize.width=startScrollView.frame.width*CGFloat(i+1)
            startScrollView.addSubview(imageView)
        }
        
    
        let loginButton=FBSDKLoginButton()
        view.addSubview(loginButton)
        loginButton.frame=CGRect(x:16,y:450,width: view.frame.width-32, height: 42)
        loginButton.delegate = self
        loginButton.readPermissions = ["email", "public_profile"]
        
        if let token = FBSDKAccessToken.current(){
            fetchProfile()
        }
    }
    func fetchProfile(){
        print("fetch profile")
        let parameters = ["fields": "id, email, first_name, last_name, picture.type(large)"]
        FBSDKGraphRequest(graphPath: "me", parameters: parameters).start(completionHandler: { (connection, result, error) -> Void in
            if (error != nil){
                print(error)
                return
            }
            let data:[String:AnyObject] = result as! [String : AnyObject]
            print(data)
            //self.getUserData(result: data as AnyObject)
        } )
    }
}
